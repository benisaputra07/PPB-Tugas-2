package com.example.restosederhana;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
public class MenuDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_detail);

        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("menu")) {
            Menu menu = (Menu) intent.getSerializableExtra("menu");
            if (menu != null) {
                ImageView imgMakanan = findViewById(R.id.detail_img_makanan);
                TextView name = findViewById(R.id.detail_name);
                TextView description = findViewById(R.id.detail_description);
                TextView price = findViewById(R.id.detail_price);

                imgMakanan.setImageResource(menu.getImageResource());
                name.setText(menu.getName());
                description.setText(menu.getDescription());
                price.setText("$" + menu.getPrice());

                Button tambahPesanan = findViewById(R.id.tambahpesanan);
                Button kurangiPesanan = findViewById(R.id.kurangipesanan);
                TextView quantityTextView = findViewById(R.id.quantity);
                TextView totalPriceTextView = findViewById(R.id.total_price);

                int quantity = menu.getQuantity();
                double totalPrice = menu.getTotalPrice();

                quantityTextView.setText(String.valueOf(quantity));
                totalPriceTextView.setText("$" + totalPrice);

                tambahPesanan.setOnClickListener(view -> {
                    menu.increaseQuantity();
                    updateQuantityAndTotalPrice(menu, quantityTextView, totalPriceTextView);
                });

                kurangiPesanan.setOnClickListener(view -> {
                    menu.decreaseQuantity();
                    updateQuantityAndTotalPrice(menu, quantityTextView, totalPriceTextView);
                });

                Button pesanButton = findViewById(R.id.pesanButton);
                pesanButton.setOnClickListener(view -> {
                    // TODO: Implement the order confirmation process here
                });
            }
        }
    }

    private void updateQuantityAndTotalPrice(Menu menu, TextView quantityTextView, TextView totalPriceTextView) {
        int quantity = menu.getQuantity();
        double totalPrice = menu.getTotalPrice();

        quantityTextView.setText(String.valueOf(quantity));
        totalPriceTextView.setText("$" + totalPrice);
    }
}
