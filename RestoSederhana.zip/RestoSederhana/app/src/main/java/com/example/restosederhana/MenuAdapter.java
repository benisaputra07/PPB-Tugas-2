package com.example.restosederhana;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MenuAdapter extends RecyclerView.Adapter<MenuAdapter.MenuViewHolder> {

    private List<Menu> menuList;
    private Context context;
    private OnItemClickListener listener;


    public MenuAdapter(List<Menu> menuList) {
        if (menuList == null) {
            throw new IllegalArgumentException("Menu list cannot be null");
        }

        for (Menu menu : menuList) {
            if (menu == null) {
                throw new IllegalArgumentException("Menu item in the list cannot be null");
            }
        }

        this.menuList = menuList;
    }

    public interface OnItemClickListener {
        void onItemClick(Menu menu);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public MenuViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        View view = LayoutInflater.from(context).inflate(R.layout.item_menu, parent, false);
        return new MenuViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MenuViewHolder holder, int position) {
        Menu menu = menuList.get(position);
        holder.imgMakanan.setImageResource(menu.getImageResource());
        holder.name.setText(menu.getName());
        holder.description.setText(menu.getDescription());
        holder.price.setText("$" + menu.getPrice());
        holder.pesan.setOnClickListener(view -> {
            menu.increaseQuantity();
            notifyDataSetChanged();
        });
    }

    @Override
    public int getItemCount() {
        return menuList.size();
    }

    class MenuViewHolder extends RecyclerView.ViewHolder {
        ImageView imgMakanan;
        TextView name;
        TextView description;
        TextView price;
        Button pesan;

        public MenuViewHolder(@NonNull View itemView) {
            super(itemView);
            imgMakanan = itemView.findViewById(R.id.img_makanan);
            name = itemView.findViewById(R.id.name);
            description = itemView.findViewById(R.id.description);
            price = itemView.findViewById(R.id.price);
            pesan = itemView.findViewById(R.id.pesan);



            itemView.setOnClickListener(view -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && listener != null) {
                    listener.onItemClick(menuList.get(position));
                }
            });
        }
    }
}
