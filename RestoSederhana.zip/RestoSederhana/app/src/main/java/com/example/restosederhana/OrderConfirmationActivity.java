package com.example.restosederhana;

import android.app.Activity;

public class OrderConfirmationActivity extends Activity {
}
