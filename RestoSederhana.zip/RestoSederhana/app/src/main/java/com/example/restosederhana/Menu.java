package com.example.restosederhana;

import java.io.Serializable;

public class Menu implements Serializable {
    private int imageResource;
    private String name;
    private String description;
    private double price;
    private int quantity;

    public Menu(int imageResource, String name, String description, double price) {
        this.imageResource = imageResource;
        this.name = name;
        this.description = description;
        this.price = price;
        this.quantity = 0;
    }

    public int getImageResource() {
        return imageResource;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void increaseQuantity() {
        quantity++;
    }

    public void decreaseQuantity() {
        if (quantity > 0) {
            quantity--;
        }
    }

    public double getTotalPrice() {
        return price * quantity;
    }
}